<?php
$rootPath = $_SERVER['DOCUMENT_ROOT'];
$Pathfile = dirname(dirname($_SERVER['PHP_SELF'], 2));
$Pathfile = $rootPath.$Pathfile;
$Pathfile = $Pathfile.'/config.php'; 
$price = $_GET['price']."0";
$order_id = $_GET['order_id'];
require_once $Pathfile;
$PaySetting = mysqli_fetch_assoc(mysqli_query($connect, "SELECT (ValuePay) FROM PaySetting WHERE NamePay = 'merchant_id_irandargh'"));
$Payment_report = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM Payment_report WHERE id_order = '$order_id'"));
if($Payment_report['price'] != $_GET['price']){
 echo "مبلغ نامعتبر"; 
 return;
}

$data = [
    'merchantID' => $PaySetting['ValuePay'], # you can see your terminal's merchant code in your panel 
    'amount' => $price, # amount of transaction in rial (amount must be between 10,000 and 500,000,000 rial)
    'callbackURL' => "https://$domainhosts/payment/irandagh/back.php", # callback url that after payment is done (successful or not) information returns to this url with POST method
    'orderId' => $order_id, # you can set your desired unique order id for transaction
];
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://dargaah.com/payment");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
# if you get SSL error (curl error 60) add 2 lines below
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
# end SSL error
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);

curl_close($ch);
$result = json_decode($response);

if ($result->status == '200') {
    header("Location: https://dargaah.com/ird/startpay/" . $result->authority);
} else {
    die('Error in connecting to gateway: ' . $result->message);
}