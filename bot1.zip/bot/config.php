<?php
/*
channel => @mirzapanel
*/
//-----------------------------database-------------------------------
$dbname = "sigma"; //  نام دیتابیس
$usernamedb = "sigma"; // نام کاربری دیتابیس
$passworddb = "Aa0930895@"; // رمز عبور دیتابیس
$connect = mysqli_connect("localhost", $usernamedb, $passworddb, $dbname);
if ($connect->connect_error) {
    die("The connection to the database failed:" . $connect->connect_error);
}
mysqli_set_charset($connect, "utf8mb4");
//-----------------------------info-------------------------------

$APIKEY = "5917613787:AAHJqw1V_kPmC4vGxTyEtgMBp6lC0FEmflM"; // توکن ربات خود را وارد کنید
$adminnumber = "6123092887";// آیدی عددی ادمین
$domainhosts = "bot.sigma-hoster.store/bot";// دامنه  هاست و مسیر سورس
$usernamebot = "sigma_hoster_bot"; //نام کاربری ربات  بدون @