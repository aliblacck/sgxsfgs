<?php
$rootPath = $_SERVER['DOCUMENT_ROOT'];
$Pathfile = dirname(dirname($_SERVER['PHP_SELF'], 2));
$Pathfiles = $rootPath.$Pathfile;
$Pathfile = $Pathfiles.'/config.php';
$jdf = $Pathfiles.'/jdf.php';
$botapi = $Pathfiles.'/botapi.php';
require_once $Pathfile;
require_once $jdf;
require_once $botapi;
echo $_POST['code'];
$PaySetting = mysqli_fetch_assoc(mysqli_query($connect, "SELECT (ValuePay) FROM PaySetting WHERE NamePay = 'merchant_id_irandargh'"));
$Payment_report = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM Payment_report WHERE id_order = '{$_POST['orderId']}' LIMIT 1"));
if(!array_key_exists('code', $_POST)) {
    throw new \Exception('callback has not valid data');
}

if ($_POST['code'] == 100) {
    $data = [
        'merchantID' => $PaySetting['ValuePay'],
        'authority' => $_POST['authority'], // you can set this variable by: $_POST['authority'],
        'amount' => $_POST['amount'], // you can set this variable by: intval($_POST['amount']),
        'orderId' => $_POST['orderId'], // you can set this variable by: $_POST['orderId'],
    ];
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, "https://dargaah.com/verification");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    # if you get SSL error (curl error 60) add 2 lines below
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    # end SSL error
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);

    curl_close($ch);
    $result = json_decode($response,true);
if($result['status'] == 100){
    $price = $Payment_report['price'];
    if($Payment_report['payment_Status'] != "paid"){
    $Balance_id = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '{$Payment_report['id_user']}' LIMIT 1"));
    $stmt = $connect->prepare("UPDATE user SET Balance = ? WHERE id = ?");
    $Balance_confrim = intval($Balance_id['Balance']) + intval($price);
    $stmt->bind_param("ss", $Balance_confrim, $Payment_report['id_user']);
    $stmt->execute();
    $stmt = $connect->prepare("UPDATE Payment_report SET payment_Status = ? WHERE id_order = ?");
    $Status_change = "paid";
    $stmt->bind_param("ss", $Status_change, $Payment_report['id_order']);
    $stmt->execute();
    sendmessage($Payment_report['id_user'],"💎 کاربر گرامی مبلغ $price تومان به کیف پول شما واریز گردید با تشکر از پرداخت شما.
    
    🛒 کد پیگیری شما: {$Payment_report['id_order']}",$keyboard,'HTML');
    deletemessage($from_id, $message_id);
    $setting = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM setting"));
$text_report = "💵 پرداخت جدید
        
آیدی عددی کاربر : $from_id
مبلغ تراکنش $price
روش پرداخت :  درگاه ایران درگاه";
echo "کبف پول شما شارژ گردید";
    if (strlen($setting['Channel_Report']) > 0) {
        sendmessage($setting['Channel_Report'], $text_report, null, 'HTML');
    }
 }
}
} else {
    die('error in transaction\'s payment: ' . $_POST['message']);
}